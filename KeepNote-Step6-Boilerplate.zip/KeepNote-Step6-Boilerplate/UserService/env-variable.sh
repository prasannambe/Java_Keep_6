#!/usr/bin/env bash
export MONGO_DATABASE=userDb
export MONGO_USERNAME=app-root
export MONGO_PASSWORD=root123
export MONGO_PORT=27017
export MONGO_HOST=localhost